package JointE;

public class Triple {
	public Triple(int left_id,int rel_id,int right_id){
		this.left_id= left_id;
		this.rel_id= rel_id;
		this.right_id=right_id;
	}
	public int getLeft_id() {
		return left_id;
	}
	public void setLeft_id(int left_id) {
		this.left_id = left_id;
	}
	public int getRel_id() {
		return rel_id;
	}
	public void setRel_id(int rel_id) {
		this.rel_id = rel_id;
	}
	public int getRight_id() {
		return right_id;
	}
	public void setRight_id(int right_id) {
		this.right_id = right_id;
	}
	public int left_id;
	public int rel_id;
	public int right_id;
	
//	public static void main(String[] args){
//		System.out.print(100*Double.valueOf("-8.298526187048468E-4"));
//	}
//	
}
