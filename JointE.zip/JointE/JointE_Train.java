package JointE;

import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Random;
import java.util.Collections;

import Original.TranslationEmbeddingNew.Pair;
import TransIforRecom.Triple;

public class JointE_Train {	

	int entity_num; // #entities
	int rel_num; //#relations
	int word_num;// #words
	int dim_num; // dimension of embedding
	double learn_rate; 
	double rel_learn_rate; 
	double word_learn_rate;
	int triple_batch_size; 
	int batch_num;
	double gamma; // the margin hyperparameter
	
//	HashMap<String, Integer> entity2id=new HashMap<String, Integer>();  
//	HashMap<Integer, String> id2entity=new HashMap<Integer, String>(); 
//	HashMap<String, Integer> rel2id=new HashMap<String, Integer>();  
//	HashMap<Integer, String> id2rel=new HashMap<Integer, String>(); 
	
	double[][] entity_embedding=null; //entity semantic embedding 
	double[][] rel_embeddingA=null;
	double[][] rel_embeddingB=null;
	double[][] word_embedding = null;
	
	//Training data 
	ArrayList<Triple> train_triple=new ArrayList<Triple>();
	ArrayList<Triple> Shuffeltrain_triple;
	int train_triple_size;
	
	//Entity description 
	HashMap<String,ArrayList<WordIdf>> entity_description = new HashMap<String,ArrayList<WordIdf>>();
	int entity_description_size;
	
	Random r=null; 

	public JointE_Train(int dim_num){
		this.dim_num=dim_num; 
	}

	public void set_parameters(double learn_rate, double rel_learn_rate, double word_learn_rate, int batch_num, double gamma){
		this.learn_rate=learn_rate;  
		this.rel_learn_rate= rel_learn_rate;
		this.word_learn_rate = word_learn_rate;
		this.batch_num=batch_num;
		this.gamma=gamma; 
	}

	public  void load_data(String infile, String file2){
		try{
			BufferedReader reader=new BufferedReader(new FileReader(infile));
			String line=null;
			while((line=reader.readLine())!=null){
					String[] cols=line.split("\\s");
					Integer left_id=Integer.parseInt(cols[0]);
					Integer rel_id=Integer.parseInt(cols[1]);
					Integer right_id=Integer.parseInt(cols[2]);
					Triple triple=new Triple(left_id, rel_id, right_id);
					train_triple.add(triple);
			}
			
			InputStreamReader reader1 = new InputStreamReader(
					new FileInputStream(file2)); 
			BufferedReader br = new BufferedReader(reader1); 
			line = "";
			while ((line=br.readLine()) != null ) {
					String[] ss = line.split(":");
					String entity_id = ss[0];
					String[] words_idfs = ss[1].trim().split("\\|");
					ArrayList<WordIdf> wi = new ArrayList<WordIdf>();
					for(String word_idf:words_idfs){
						String[] temp = word_idf.trim().split("\\s");
						WordIdf woid = new WordIdf(Integer.valueOf(temp[0]),Double.valueOf(temp[1]));
						wi.add(woid);
					}
					entity_description.put(entity_id, wi);
			
			}
		}catch(IOException e){
			e.printStackTrace();
		}
	}
	
	
	public void initialize(){
		this.entity_embedding=new double[entity_num][dim_num]; 
		this.rel_embeddingA= new double[rel_num][dim_num]; 
		this.rel_embeddingB= new double[rel_num][dim_num];  
		this.word_embedding = new double[word_num][dim_num];
		this.train_triple_size=train_triple.size(); 
		this.entity_description_size = entity_description.size();
		this.triple_batch_size=this.train_triple_size/this.batch_num; 
		
		System.out.println("Total entity number:"+this.entity_num);
		System.out.println("Total relation number:"+this.rel_num);
		System.out.println("Total word number:"+this.word_num);
		System.out.println("Train triple number:"+this.train_triple_size);
		
		r=new Random();
		r.setSeed(1000);
		double sum=0;
		
		//initialize the entity and relation embedding 
		for(int i=0;i<entity_num;i++){
			sum=0;
			for(int k=0;k<dim_num;k++){
				double value=r.nextGaussian();
				this.entity_embedding[i][k]=value/10;
			}
		}
		for(int i=0;i<rel_num;i++){
			sum=0;
			for(int k=0;k<dim_num;k++){
				double value=r.nextGaussian();
				this.rel_embeddingA[i][k]=value/10;
			}
		}
		for(int i=0;i<rel_num;i++){
			sum=0;
			for(int k=0;k<dim_num;k++){
				double value=r.nextGaussian();
				this.rel_embeddingB[i][k]=value/10;
			}
		}
		for(int i=0;i<word_num;i++){
			sum=0;
			for(int k=0;k<dim_num;k++){
				double value=r.nextGaussian();
				this.word_embedding[i][k]=value/10;
			}
		}
	}
	
	/**
	 * 
	 * @param max_iter
	 */
	public void train(int max_iter,String tag){
		this.initialize();
		ArrayList<Integer> index=new ArrayList<Integer>();
		for(int i=0;i<train_triple_size;i++) 
			index.add(i);
		ArrayList<Double> cost=new ArrayList<Double>();
		ArrayList<Integer> mis_instance=new ArrayList<Integer>();

		double avg_cost=0;
		for(int iter=0;iter<max_iter;iter++){
			Shuffeltrain_triple=new ArrayList<Triple>();
			cost.clear();
			mis_instance.clear();
			Collections.shuffle(index);
			for(int i=0;i<train_triple_size;i++){
				Shuffeltrain_triple.add(train_triple.get(index.get(i)));
			} 
			
			ArrayList<Triple> tmp_train_triple=new ArrayList<Triple>();
			ArrayList<Triple> tmp_train_triple_neg=new ArrayList<Triple>();
			
			for(int n=0;n<train_triple_size;n++){
				
				if((n>0&&n%triple_batch_size==0)||n==train_triple_size-1){
					if(n==train_triple_size-1){
						Triple triple=Shuffeltrain_triple.get(n);
						tmp_train_triple.add(triple);
						
						if(new Random().nextDouble()<0.5){
							int corru_left=r.nextInt(entity_num); 
							Triple triple_neg=new Triple(corru_left,triple.rel_id,triple.right_id);
							tmp_train_triple_neg.add(triple_neg); 
							
						}else{
							int corru_right=r.nextInt(entity_num);
							Triple triple_neg=new Triple(triple.left_id,triple.rel_id,corru_right);
							tmp_train_triple_neg.add(triple_neg); 
							
						}
					}
					
					Pair pair=this.update_embeddings_triple(tmp_train_triple, tmp_train_triple_neg,iter,tag);
					cost.add(pair.cost);
					mis_instance.addAll(pair.list);
					
					tmp_train_triple.clear();
					tmp_train_triple_neg.clear();

				}// end if
				
				Triple triple=Shuffeltrain_triple.get(n);
				tmp_train_triple.add(triple); //������
				
				if(new Random().nextDouble()<0.5){
					int corru_left=r.nextInt(entity_num); 
					Triple triple_neg=new Triple(corru_left,triple.rel_id,triple.right_id);
					tmp_train_triple_neg.add(triple_neg); //������
					
				}else{
					int corru_right=r.nextInt(entity_num);
					Triple triple_neg=new Triple(triple.left_id,triple.rel_id,corru_right);
					tmp_train_triple_neg.add(triple_neg); //������
					
				}
			}// end for

			//Report the results on the training data
			avg_cost=0;
			for(int n=0;n<cost.size();n++)
				avg_cost+=cost.get(n);
			avg_cost/=cost.size();
			double error_percentage=0;
			for(int n=0;n<mis_instance.size();n++)
				error_percentage+=mis_instance.get(n);
			error_percentage/=mis_instance.size();
			System.out.println("iter="+iter+"\tcost="+avg_cost+"\terror="+error_percentage);
		}
	}

	class Pair{
		double cost;
		ArrayList<Integer> list=null; 
		public Pair(double cost, ArrayList<Integer> list){
			this.cost=cost;
			this.list=list;
		}
	}
	public double[] cal_ent_sem(int entity_id, String tag){
		double[] temp = new double[dim_num];
		ArrayList<WordIdf> alwi = entity_description.get(String.valueOf(entity_id));
		double aver = 1.0/alwi.size();
		for(int k=0;k<dim_num;k++){
			for(WordIdf wi : alwi){
				int word_id = wi.getWord_id();
				double tfidf;
				if(tag.equalsIgnoreCase("wbow")){
					tfidf = wi.getWord_idf();
				}else{
					tfidf = aver;
				}
				temp[k] += tfidf*word_embedding[word_id][k];
			}
		}
		return temp;
	}
	
	public double[] doubletimes(double d , double[] e){
		double[] newd = new double[e.length];
		for(int k = 0;k<newd.length;k++){
			newd[k] = d*e[k];
		}
		return newd;
	}
	/**
	 * ����Ϊ��������������
	 * @param positives
	 * @param negatives
	 * @return
	 */
	public Pair update_embeddings_triple(ArrayList<Triple> positives, ArrayList<Triple> negatives,int iter,String tag){
	
		int size =positives.size();
		double score=0;
		ArrayList<Integer> list=new ArrayList<Integer>();
		
		double[][] rel_gradientA=new double[rel_num][dim_num];
		double[][] rel_gradientB=new double[rel_num][dim_num];
		double[][] word_gradient = new double[word_num][dim_num];
		for(int n=0;n<size;n++){
			//ÿһ������ ����
			Triple triple=positives.get(n);
			int left_id=triple.left_id;
			int right_id=triple.right_id;
			int rel_id=triple.rel_id;
			
			Triple triple_neg=negatives.get(n);
			int left_id_neg=triple_neg.left_id;
			int right_id_neg=triple_neg.right_id;
			int rel_id_neg=triple_neg.rel_id;
			
			
			//get the entity semantic embedding
			entity_embedding[left_id]= cal_ent_sem(left_id,tag);		
			entity_embedding[right_id]= cal_ent_sem(right_id,tag);		
			entity_embedding[left_id_neg]= cal_ent_sem(left_id_neg,tag);		
			entity_embedding[right_id_neg]= cal_ent_sem(right_id_neg,tag);		
			

			double cost_pos=dot(entity_embedding[left_id],entity_embedding[right_id])
					+dot(entity_embedding[left_id],rel_embeddingA[rel_id])
					+dot(entity_embedding[right_id],rel_embeddingB[rel_id])
					;
			
			double cost_neg=dot(entity_embedding[left_id_neg],entity_embedding[right_id_neg])
					+dot(entity_embedding[left_id_neg],rel_embeddingA[rel_id_neg])
					+dot(entity_embedding[right_id_neg],rel_embeddingB[rel_id_neg])
					;
			double cost=this.gamma-cost_pos+cost_neg;
			if(cost>0){
				list.add(1);
				score+=cost;
			}
			else{
				list.add(0);
			}
			if(cost<=0)
				continue;

			// update the embedding first;
			for(int k=0;k<dim_num;k++){
				rel_gradientA[rel_id][k]+=-entity_embedding[left_id][k];
				rel_gradientB[rel_id][k]+=-entity_embedding[right_id][k];
				
				rel_gradientA[rel_id_neg][k]+=entity_embedding[left_id_neg][k];
				rel_gradientB[rel_id_neg][k]+=entity_embedding[right_id_neg][k];
			}
			
			//calculate the gradient of word embedding
			ArrayList<WordIdf> alwi = entity_description.get(String.valueOf(left_id));
			double aver = 1.0/alwi.size();
				for(WordIdf wi : alwi){
					int word_id = wi.getWord_id();
					double tfidf;
					if(tag.equalsIgnoreCase("wbow")){
						tfidf = wi.getWord_idf();
					}else{
						tfidf = aver;
					}
					for(int k =0;k<dim_num;k++){
						word_gradient[word_id][k]+=-tfidf*(entity_embedding[right_id][k]+rel_embeddingA[rel_id][k]);
					}
				}
				
			alwi = entity_description.get(String.valueOf(right_id));
			aver = 1.0/alwi.size();
				for(WordIdf wi : alwi){
					int word_id = wi.getWord_id();
					double tfidf;
					if(tag.equalsIgnoreCase("wbow")){
						tfidf = wi.getWord_idf();
					}else{
						tfidf = aver;
					}
					for(int k =0;k<dim_num;k++){
						word_gradient[word_id][k]+=-tfidf*(entity_embedding[left_id][k]+rel_embeddingB[rel_id][k]);
					}
				}
				
			alwi = entity_description.get(String.valueOf(left_id_neg));
			aver = 1.0/alwi.size();
				for(WordIdf wi : alwi){
					int word_id = wi.getWord_id();
					double tfidf;
					if(tag.equalsIgnoreCase("wbow")){
						tfidf = wi.getWord_idf();
					}else{
						tfidf = aver;
					}
					for(int k =0;k<dim_num;k++){
						word_gradient[word_id][k]+=tfidf*(entity_embedding[right_id_neg][k]+rel_embeddingA[rel_id_neg][k]);
					}
				}	
			alwi = entity_description.get(String.valueOf(right_id_neg));
			aver = 1.0/alwi.size();
				for(WordIdf wi : alwi){
					int word_id = wi.getWord_id();
					double tfidf;
					if(tag.equalsIgnoreCase("wbow")){
						tfidf = wi.getWord_idf();
					}else{
						tfidf =aver;
					}
					for(int k =0;k<dim_num;k++){
						word_gradient[word_id][k]+=tfidf*(entity_embedding[left_id_neg][k]+rel_embeddingB[rel_id_neg][k]);
					}
				}	
					
				
				
				
		}
		for(int i=0;i<rel_num;i++){
			for(int k=0;k<dim_num;k++)
			rel_embeddingA[i][k]-=rel_learn_rate*(rel_gradientA[i][k]);

		}
		for(int i=0;i<rel_num;i++){
			for(int k=0;k<dim_num;k++)
			rel_embeddingB[i][k]-=rel_learn_rate*(rel_gradientB[i][k]);
			
		}
		for(int i=0;i<word_num;i++){
			for(int k=0;k<dim_num;k++)
				word_embedding[i][k]-=word_learn_rate*(word_gradient[i][k]);
			
		}
		
		this.normalize_embeddings();  //The l2 norm of the embeddings is less or equal 1;
		
		Pair pair=new Pair(score/positives.size(),list);
		return pair;
	}
	public void normalize_embeddings(){
		double sum=0;
		for(int i=0;i<entity_num;i++){
			sum=0;
			for(int k=0;k<dim_num;k++)
				sum+=this.entity_embedding[i][k]*this.entity_embedding[i][k];
			for(int k=0;k<dim_num;k++)
				this.entity_embedding[i][k]/=Math.sqrt(sum);
		}
		for(int i=0;i<rel_num;i++){
			sum=0;
			for(int k=0;k<dim_num;k++)
				sum+=this.rel_embeddingA[i][k]*this.rel_embeddingA[i][k];
			for(int k=0;k<dim_num;k++)
				this.rel_embeddingA[i][k]/=Math.sqrt(sum);
			
			sum=0;
			for(int k=0;k<dim_num;k++)
				sum+=this.rel_embeddingB[i][k]*this.rel_embeddingB[i][k];
			for(int k=0;k<dim_num;k++)
				this.rel_embeddingB[i][k]/=Math.sqrt(sum);
			
		}
	}
	
	
	public void output_model_file_A(String model_file){
		try{
			BufferedWriter writer=new BufferedWriter(new FileWriter(model_file));
			writer.write(this.dim_num+"\t"+this.entity_num+"\t"+this.rel_num);
			writer.newLine();
			for(int i=0;i<entity_num;i++){
				writer.write(i+"\t");
				for(int n=0;n<dim_num;n++){
					if(n==0){
						writer.write(String.valueOf(this.entity_embedding[i][n]));
					}else
						writer.write(" "+this.entity_embedding[i][n]);
				}
				writer.newLine();
			}
			for(int i=0;i<rel_num;i++){
				writer.write(i+"\t");
				for(int n=0;n<dim_num;n++){
					if(n==0){
						writer.write(String.valueOf(this.rel_embeddingA[i][n]));
					}else
						writer.write(" "+this.rel_embeddingA[i][n]);
				}
				writer.newLine();
			}
			writer.flush();
			writer.close();
		}catch(IOException e){
			e.printStackTrace();
		}
	}
	
	public void output_model_file_B(String model_file){
		try{
			BufferedWriter writer=new BufferedWriter(new FileWriter(model_file));
			writer.write(this.dim_num+"\t"+this.entity_num+"\t"+this.rel_num);
			writer.newLine();
			for(int i=0;i<entity_num;i++){
				writer.write(i+"\t");
				for(int n=0;n<dim_num;n++){
					if(n==0){
						writer.write(String.valueOf(this.entity_embedding[i][n]));
					}else
						writer.write(" "+this.entity_embedding[i][n]);
				}
				writer.newLine();
			}
			for(int i=0;i<rel_num;i++){
				writer.write(i+"\t");
				for(int n=0;n<dim_num;n++){
					if(n==0){
						writer.write(String.valueOf(this.rel_embeddingB[i][n]));
					}else
						writer.write(" "+this.rel_embeddingB[i][n]);
				}
				writer.newLine();
			}
			writer.flush();
			writer.close();
		}catch(IOException e){
			e.printStackTrace();
		}
	}
	public void output_model_file_word_embedding(String model_file){
		try{
			BufferedWriter writer=new BufferedWriter(new FileWriter(model_file));
			writer.write(this.dim_num+"\t"+this.word_num+"\t");
			writer.newLine();
			for(int i=0;i<word_num;i++){
				writer.write(i+"\t");
				for(int n=0;n<dim_num;n++){
					if(n==0){
						writer.write(String.valueOf(this.word_embedding[i][n]));
					}else
						writer.write(" "+this.word_embedding[i][n]);
				}
				writer.newLine();
			}
			writer.flush();
			writer.close();
		}catch(IOException e){
			e.printStackTrace();
		}
	}
	
	class EntityScore implements Comparable {
		int id;
		double score;
		public EntityScore (int id, double score) { this.id = id; this.score = score; }
		public final int compareTo (Object o2) {
			if (score > ((EntityScore)o2).score)
				return -1;
			else if (score == ((EntityScore)o2).score)
				return 0;
			else return 1;
		}
	}
	/**
	 * 
	 * @param x
	 * @param y
	 * @return
	 */
	public static double[] sum(double[] x,double[] y){
		int dim=x.length;
		double[] sum=new double[dim];
		for(int k=0;k<dim;k++){
			sum[k]=(x[k]+y[k]);
		}
		return sum;
	}
	/**
	 * 
	 * @param x
	 * @param y
	 * @return
	 */
	public static double dot(double[] x,double[] y){
		int dim=x.length;
		double sum=0.0;
		for(int k=0;k<dim;k++){
			sum+=(x[k]*y[k]);
		}
		return sum;
	}
	/**
	 * 
	 * @param x
	 * @param y
	 * @return
	 */
	public static double[] subtract(double[] x,double[] y){
		int dim=x.length;
		double[] result=new double[dim];
		for(int k=0;k<dim;k++){
			result[k]=(x[k]-y[k]);
		}
		return result;
	}
	/**
	 * cos
	 * @param x
	 * @param y
	 * @return
	 */
	public static double cos(double[] x,double[] y){
		int dim=x.length;
		double up =0.0, downX =0.0,downY=0.0;
		for(int k=0;k<dim;k++){
			up +=x[k]*y[k];
		}
		for(int k=0;k<dim;k++){
			downX +=x[k]*x[k];
		}
		for(int k=0;k<dim;k++){
			downY +=y[k]*y[k];
		}
		
		return up/(Math.sqrt(downX)*Math.sqrt(downY));
	}
	
	/**
	 * 
	 * @param x
	 * @return
	 */
	public static double l1_norm(double[] x){
		int dim=x.length;
		double result=0;
		for(int k=0;k<dim;k++){
			result+=Math.abs(x[k]);
		}
		return result;
	}
	
	public ArrayList<Triple> get_sublist(ArrayList<Triple> list, int num){
		ArrayList<Triple> result=new ArrayList<Triple>();
		if(num>list.size())
			num=list.size();
		for(int n=0;n<num;n++)
			result.add(list.get(n));
		return result;
	}
	
	
	public static void main(String[] args){
		int[] dim_nums = new int[]{50,100,200};  //dimension
		double[] gammas = new double[]{1.0,2.0,5.0};  //gamma
		String[] tags = new String[]{"cbow","wbow"}; //CBOW or WBOW
		double learn_rate=0.01; // learning rate
		double rel_learn_rate = 0.01; // learning rate
		double word_learn_rate = 0.01; // learning rate
		int batch_num=100; //default  
		int iter_num=1000;//default
		
		String train_file="../WN35K/train.txt";
		String file = "../WN35K/in_entity-definitions_tfidf.txt";
		
		for(int i = 0;i<dim_nums.length;i++){
			int dim_num=dim_nums[i];//default
			for(int j =0;j<gammas.length;j++){
				double gamma=gammas[j];//default
				for(String tag:tags){
					String  modelparameter = "lr"+learn_rate+"_rlr"+rel_learn_rate+"_wlr"+word_learn_rate+"_dim"+dim_num+"_gamma"+gamma+"_"+tag;
					System.out.println(modelparameter);
					String embeddingA="../WN35K/embedding("+modelparameter+")_A.txt";
					String embeddingB="../WN35K/embedding("+modelparameter+")_B.txt";
					String word_embedding="../WN35K/word_embedding("+modelparameter+").txt";
					
					JointE_Train te=new JointE_Train(dim_num);
					te.load_data(train_file,file);	
					te.entity_num=28307; //#In-KG entities
					te.rel_num=18; // #relations
					te.word_num = 28601; //#words
					te.set_parameters(learn_rate,rel_learn_rate,word_learn_rate,batch_num,gamma);
					te.train(iter_num,tag);
					te.output_model_file_A(embeddingA);
					te.output_model_file_B(embeddingB);
					te.output_model_file_word_embedding(word_embedding);
				}
			}
		}
	}

}