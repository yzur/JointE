package JointE;
import java.io.*;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Random;


public class JointE_Test {

	int dim_num;
	int entity_num;
	int rel_num;
	int word_num;
	
	double[][] entity_embedding;
	double[][] rel_embeddingA;
	double[][] rel_embeddingB;
	double[][] word_embedding;
	double[][] out_entity_embedding;
	
	//test data ids
	ArrayList<Integer> left_entity;
	ArrayList<Integer> right_entity;
	ArrayList<Integer> relation;
	
	//Entity description 
	HashMap<String,ArrayList<WordIdf>> entity_description = new HashMap<String,ArrayList<WordIdf>>();
	int entity_description_size;
	
	int de_test_size = 16798;
	int ed_test_size = 16759;
	int dd_test_size = 4000;
	
	int topn;
	String tag;
	
    int[][] de_result=new int[de_test_size][2];
    int[] de_relation_result=new int[de_test_size];
    
    int[][] ed_result=new int[ed_test_size][2];
    int[] ed_relation_result=new int[ed_test_size];
    
    int[][] dd_result=new int[dd_test_size][2];
    int[] dd_relation_result=new int[dd_test_size];
    
	public JointE_Test(int topn, String tag){
		this.topn=topn;
		this.tag = tag;
	}
	
	public void load_model_A(String model_file){
		try{
			BufferedReader reader=new BufferedReader(new FileReader(model_file));
			String line=null;
			int line_id=0;
			while((line=reader.readLine())!=null){
				if(line_id==0){
					String[] cols=line.split("\t");
					dim_num=Integer.parseInt(cols[0]);
					entity_num=Integer.parseInt(cols[1]);
					rel_num=Integer.parseInt(cols[2]);
					this.entity_embedding=new double[entity_num][dim_num];
					this.rel_embeddingA=new double[rel_num][dim_num];
					line_id++;
					continue;
				}
				//load entity embeddings
				String[] cols=line.split("\t");
				if(line_id<=entity_num){
					int entity_id=Integer.parseInt(cols[0]);
					String[] values=cols[1].split(" ");
					for(int n=0;n<dim_num;n++)
						this.entity_embedding[entity_id][n]=Double.parseDouble(values[n]);
				}else{
					int rel_id=Integer.parseInt(cols[0]);
					String[] values=cols[1].split(" ");
					for(int n=0;n<dim_num;n++)
						this.rel_embeddingA[rel_id][n]=Double.parseDouble(values[n]);
				}
				line_id++;
			}
		}catch(IOException e){
			e.printStackTrace();
		}
	}
	public void load_model_B(String model_file){
		try{
			BufferedReader reader=new BufferedReader(new FileReader(model_file));
			String line=null;
			int line_id=0;
			while((line=reader.readLine())!=null){
				if(line_id==0){
					String[] cols=line.split("\t");
					dim_num=Integer.parseInt(cols[0]);
					entity_num=Integer.parseInt(cols[1]);
					rel_num=Integer.parseInt(cols[2]);
//					this.entity_embeddingB=new double[entity_num][dim_num];
					this.rel_embeddingB=new double[rel_num][dim_num];
					line_id++;
					continue;
				}
				String[] cols=line.split("\t");
				if(line_id<=entity_num){
					int entity_id=Integer.parseInt(cols[0]);
					String[] values=cols[1].split(" ");
//					for(int n=0;n<dim_num;n++)
//						this.entity_embeddingB[entity_id][n]=Double.parseDouble(values[n]);
				}else{
					int rel_id=Integer.parseInt(cols[0]);
					String[] values=cols[1].split(" ");
					for(int n=0;n<dim_num;n++)
						this.rel_embeddingB[rel_id][n]=Double.parseDouble(values[n]);
				}
				line_id++;
			}
			System.out.println("Dimension number:"+this.dim_num);
			System.out.println("Entity number:"+this.entity_num);
			System.out.println("Relation number:"+this.rel_num);
		}catch(IOException e){
			e.printStackTrace();
		}
	}
	public void load_model_word_embedding(String model_file){
		try{
			BufferedReader reader=new BufferedReader(new FileReader(model_file));
			String line=null;
			int line_id=0;
			while((line=reader.readLine())!=null){
				if(line_id==0){
					String[] cols=line.split("\t");
					dim_num=Integer.parseInt(cols[0]);
					word_num=Integer.parseInt(cols[1]);
					this.word_embedding=new double[word_num][dim_num];
					line_id++;
					continue;
				}
				//load word embeddings
				String[] cols=line.split("\t");
				if(line_id<=word_num){
					int word_id=Integer.parseInt(cols[0]);
					String[] values=cols[1].split(" ");
					for(int n=0;n<dim_num;n++)
						this.word_embedding[word_id][n]=Double.parseDouble(values[n]);
				}
				line_id++;
			}
			System.out.println("Word number:"+this.word_num);
		}catch(IOException e){
			e.printStackTrace();
		}
	}
	public void load_testdata(String test_file,String tag){
		this.left_entity=new ArrayList<Integer>();
		this.right_entity=new ArrayList<Integer>();
		this.relation=new ArrayList<Integer>();
	
		try{
			BufferedReader reader=new BufferedReader(new FileReader(test_file));
			String line=null;
			while((line=reader.readLine())!=null){
				String[] cols=line.split("\\s");
				this.left_entity.add(Integer.parseInt(cols[0]));
				this.relation.add(Integer.parseInt(cols[1]));
				this.right_entity.add(Integer.parseInt(cols[2]));
			}
			System.out.println(tag+" _Number of triples in test data:"+this.left_entity.size());
		}catch(IOException e){
			e.printStackTrace();
		}
	}
	public static double dot(double[] x,double[] y){
		int dim=x.length;
		double sum=0.0;
		for(int k=0;k<dim;k++){
			sum+=(x[k]*y[k]);
		}
		return sum;
	}
	
	public static double l1_norm(double[] x,double[] y){
		int dim=x.length;
		double sum=0.0;
		for(int k=0;k<dim;k++){
			sum+=Math.abs(x[k]-y[k]);
		}
		return sum;
	}
	public double[] cal_ent_sem(int entity_id){
		double[] temp = new double[dim_num];
		if(entity_description.containsKey(String.valueOf(entity_id))){
			ArrayList<WordIdf> alwi = entity_description.get(String.valueOf(entity_id));
			int c = alwi.size();
			for(int k=0;k<dim_num;k++){
				for(WordIdf wi : alwi){
					int word_id = wi.getWord_id();
					double tfidf;
					if(this.tag.equalsIgnoreCase("wbow")){
						tfidf = wi.getWord_idf();
					}else{
						tfidf = 1.0/c;
					}
					temp[k] += tfidf*word_embedding[word_id][k];
				}
			}
		}else{
			Random r = new Random();
			for(int k=0;k<dim_num;k++){
				double value=r.nextGaussian();
				temp[k]=value/10;
			}
		}
		return temp;
	}
	
	public void evaluation(int n,String tag){
		ArrayList<Integer> pair=null;
		EntityScore[] entity_score=new EntityScore[entity_num];
		EntityScore[] head_score=new EntityScore[entity_num+1];//predict head +1
		
		int left_id=left_entity.get(n);
		int right_id=right_entity.get(n);
		int rel_id=relation.get(n);
		if(tag.equalsIgnoreCase("de")){
			// predict tail;
			for(int d=0;d<this.entity_num;d++){
				entity_score[d]=new EntityScore(d,dot(out_entity_embedding[left_id],entity_embedding[d])
						+dot(out_entity_embedding[left_id],rel_embeddingA[rel_id])
						+dot(entity_embedding[d],rel_embeddingB[rel_id]));
			}
			Arrays.sort(entity_score);	
			pair=new ArrayList<Integer>();
			for(int d=0;d<this.entity_num;d++){
				if(entity_score[d].id==right_id){
					pair.add(d+1);
					break;
				}
			}
			//predict head;
			for(int d=0;d<this.entity_num;d++){
				head_score[d]=new EntityScore(d,dot(entity_embedding[d],entity_embedding[right_id])
						+dot(entity_embedding[d],rel_embeddingA[rel_id])
						+dot(entity_embedding[right_id],rel_embeddingB[rel_id])
						);
			}
			head_score[entity_num] = new EntityScore(entity_num,dot(out_entity_embedding[left_id],entity_embedding[right_id])
					+dot(out_entity_embedding[left_id],rel_embeddingA[rel_id])
					+dot(entity_embedding[right_id],rel_embeddingB[rel_id])); // 
			
			
			Arrays.sort(head_score);
			for(int d=0;d<this.entity_num+1;d++){
				if(head_score[d].id==entity_num){
					pair.add(d+1);
					break;
				}
			}
			this.de_result[n][1]=pair.get(1);
			this.de_result[n][0]=pair.get(0);
		}else if(tag.equalsIgnoreCase("ed")){
			// predict tail;
			for(int d=0;d<this.entity_num;d++){
				head_score[d]=new EntityScore(d,dot(entity_embedding[left_id],entity_embedding[d])
													+dot(entity_embedding[left_id],rel_embeddingA[rel_id])
														+dot(entity_embedding[d],rel_embeddingB[rel_id]));
			}
			head_score[entity_num]=new EntityScore(entity_num,dot(entity_embedding[left_id],out_entity_embedding[right_id])
					+dot(entity_embedding[left_id],rel_embeddingA[rel_id])
						+dot(out_entity_embedding[right_id],rel_embeddingB[rel_id]));
			Arrays.sort(head_score);	
			pair=new ArrayList<Integer>();
			for(int d=0;d<this.entity_num+1;d++){
				if(head_score[d].id==entity_num){
					pair.add(d+1);
					break;
				}
			}
			//predict head;
			for(int d=0;d<this.entity_num;d++){
				entity_score[d]=new EntityScore(d,dot(entity_embedding[d],out_entity_embedding[right_id])
													+dot(entity_embedding[d],rel_embeddingA[rel_id])
													+dot(out_entity_embedding[right_id],rel_embeddingB[rel_id]));
			}
			Arrays.sort(entity_score);
			for(int d=0;d<this.entity_num;d++){
				if(entity_score[d].id==left_id){
					pair.add(d+1);
					break;
				}
			}
			this.ed_result[n][1]=pair.get(1);
			this.ed_result[n][0]=pair.get(0);
		}else if(tag.equalsIgnoreCase("dd")){
			// predict tail
			for(int d=0;d<this.entity_num;d++){
				head_score[d]=new EntityScore(d,dot(out_entity_embedding[left_id],entity_embedding[d])
													+dot(out_entity_embedding[left_id],rel_embeddingA[rel_id])
														+dot(entity_embedding[d],rel_embeddingB[rel_id]));
			}
			head_score[entity_num]=new EntityScore(entity_num,dot(out_entity_embedding[left_id],out_entity_embedding[right_id])
					+dot(out_entity_embedding[left_id],rel_embeddingA[rel_id])
						+dot(out_entity_embedding[right_id],rel_embeddingB[rel_id]));
			Arrays.sort(head_score);	
			pair=new ArrayList<Integer>();
			for(int d=0;d<this.entity_num+1;d++){
				if(head_score[d].id==entity_num){
					pair.add(d+1);
					break;
				}
			}
			//predict head;
			for(int d=0;d<this.entity_num;d++){
				head_score[d]=new EntityScore(d,dot(entity_embedding[d],out_entity_embedding[right_id])
													+dot(entity_embedding[d],rel_embeddingA[rel_id])
													+dot(out_entity_embedding[right_id],rel_embeddingB[rel_id]));
			}
			head_score[entity_num]=new EntityScore(entity_num,dot(out_entity_embedding[left_id],out_entity_embedding[right_id])
					+dot(out_entity_embedding[left_id],rel_embeddingA[rel_id])
						+dot(out_entity_embedding[right_id],rel_embeddingB[rel_id]));
			Arrays.sort(head_score);
			for(int d=0;d<this.entity_num+1;d++){
				if(head_score[d].id==entity_num){
					pair.add(d+1);
					break;
				}
			}
			this.dd_result[n][1]=pair.get(1);
			this.dd_result[n][0]=pair.get(0);
		}
	}
	
	public void zs_evaluation_all(){
		// calculate various score
				int left_rank=0,right_rank=0, global_rank=0;
				int left_hits=0,right_hits=0, global_hits=0;
				
				int  t_num = de_test_size+ed_test_size+dd_test_size;
				int[][] result=new int [t_num][2];
				for(int i=0;i<de_test_size;i++){
					result[i]=de_result[i];
				}
				for(int i = 0;i<ed_test_size;i++){
					result[de_test_size+i]=ed_result[i];
				}
				for(int i=0;i<dd_test_size;i++){
					result[de_test_size+ed_test_size+i]=dd_result[i];
				}
				
				for(int n=0;n<t_num;n++){
					left_rank+=result[n][1];
					right_rank+=result[n][0];
					global_rank+=result[n][1];
					global_rank+=result[n][0];
					
					if(result[n][1]<=topn){
						left_hits+=1;
						global_hits+=1;
					}
					if(result[n][0]<=topn){
						right_hits+=1;
						global_hits+=1;
					}
				}
				int size=t_num;

				System.out.println("microlmean:"+ 1.0*left_rank/size);
			    System.out.println("microlhits@n:"+1.0*left_hits/size);
			    System.out.println("micrormean:"+ 1.0*right_rank/size);
			    System.out.println("microrhits@n:"+ 1.0*right_hits/size);
			    System.out.println("microgmean:"+ 1.0*global_rank/(2*size));
			    System.out.println("all_ microghits@n:"+ 1.0*global_hits/(2*size));
				System.out.println();
				
	}
	
	public void zs_evaluation(String tag){
		if(tag.equalsIgnoreCase("de")){
			long startTime=System.currentTimeMillis();   
			for (int d = 0; d<de_test_size; d++)
			{
				evaluation(d,tag);
				if(d%1000==0){
					long endTime=System.currentTimeMillis(); 
//					System.out.println(d+ " ��������ʱ�䣺 "+(endTime-startTime)+"ms");
					startTime = endTime;
				}
			}
			// calculate various score
			int left_rank=0,right_rank=0, global_rank=0;
			int left_hits=0,right_hits=0, global_hits=0;
			
			for(int n=0;n<this.de_test_size;n++){
				
				left_rank+=this.de_result[n][1];
				right_rank+=this.de_result[n][0];
				global_rank+=this.de_result[n][1];
				global_rank+=this.de_result[n][0];
				
				if(this.de_result[n][1]<=topn){
					left_hits+=1;
					global_hits+=1;
				}
				if(this.de_result[n][0]<=topn){
					right_hits+=1;
					global_hits+=1;
				}
			}	
			int size=this.de_test_size;
			
			System.out.println("microlmean:"+ 1.0*left_rank/size);
			System.out.println("microlhits@n:"+1.0*left_hits/size);
			System.out.println("micrormean:"+ 1.0*right_rank/size);
			System.out.println("microrhits@n:"+ 1.0*right_hits/size);
			System.out.println("microgmean:"+ 1.0*global_rank/(2*size));
			System.out.println("de_microghits@n:"+ 1.0*global_hits/(2*size));
			System.out.println();
			
		} else if(tag.equalsIgnoreCase("ed")){
			long startTime=System.currentTimeMillis();  
			for (int d = 0; d<ed_test_size; d++)
			{
				evaluation(d,tag);
				if(d%100==0){
					long endTime=System.currentTimeMillis(); //��ȡ����ʱ��
					startTime = endTime;
				}
			}
			// calculate various score
			int left_rank=0,right_rank=0, global_rank=0;
			int left_hits=0,right_hits=0, global_hits=0;
			
			for(int n=0;n<this.ed_test_size;n++){
				
				left_rank+=this.ed_result[n][1];
				right_rank+=this.ed_result[n][0];
				global_rank+=this.ed_result[n][1];
				global_rank+=this.ed_result[n][0];
				
				if(this.ed_result[n][1]<=topn){
					left_hits+=1;
					global_hits+=1;
				}
				if(this.ed_result[n][0]<=topn){
					right_hits+=1;
					global_hits+=1;
				}
			}
			int size=this.ed_test_size;
			
			System.out.println("microlmean:"+ 1.0*left_rank/size);
			System.out.println("microlhits@n:"+1.0*left_hits/size);
			System.out.println("micrormean:"+ 1.0*right_rank/size);
			System.out.println("microrhits@n:"+ 1.0*right_hits/size);
			System.out.println("microgmean:"+ 1.0*global_rank/(2*size));
			System.out.println("ed_microghits@n:"+ 1.0*global_hits/(2*size));
			System.out.println();
			
		} else if(tag.equalsIgnoreCase("dd")){
			long startTime=System.currentTimeMillis();  
			for (int d = 0; d<dd_test_size; d++)
			{
				evaluation(d,tag);
				if(d%100==0){
					long endTime=System.currentTimeMillis(); 
//					System.out.println(d+ " runtime�� "+(endTime-startTime)+"ms");
					startTime = endTime;
				}
			}
			// calculate various score
			int left_rank=0,right_rank=0, global_rank=0;
			int left_hits=0,right_hits=0, global_hits=0;
			
			for(int n=0;n<this.dd_test_size;n++){
				left_rank+=this.dd_result[n][1];
				right_rank+=this.dd_result[n][0];
				global_rank+=this.dd_result[n][1];
				global_rank+=this.dd_result[n][0];
				
				if(this.dd_result[n][1]<=topn){
					left_hits+=1;
					global_hits+=1;
				}
				if(this.dd_result[n][0]<=topn){
					right_hits+=1;
					global_hits+=1;
				}
				
			}
			int size=this.dd_test_size;
			
			System.out.println("microlmean:"+ 1.0*left_rank/size);
			System.out.println("microlhits@n:"+1.0*left_hits/size);
			System.out.println("micrormean:"+ 1.0*right_rank/size);
			System.out.println("microrhits@n:"+ 1.0*right_hits/size);
			System.out.println("microgmean:"+ 1.0*global_rank/(2*size));
			System.out.println("dd_microghits@n:"+ 1.0*global_hits/(2*size));
			System.out.println();
			
		}
		
		
	}
	
	class EntityScore implements Comparable {
		int id;
		double score;
		public EntityScore (int id, double score) { this.id = id; this.score = score; }
		public final int compareTo (Object o2) {
			if (score > ((EntityScore)o2).score)
				return -1;
			else if (score == ((EntityScore)o2).score)
				return 0;
			else return 1;
		}
	}
	
  	public void load_description(String file2){
		try{
			InputStreamReader reader1 = new InputStreamReader(
					new FileInputStream(file2)); 
			BufferedReader br = new BufferedReader(reader1); 
			String line = "";
			int out_entity_size = 0;
			while ((line=br.readLine()) != null ) {
					String[] ss = line.split(":");
					String entity_id = ss[0];
					if(!ss[1].trim().equalsIgnoreCase("")){
					String[] words_idfs = ss[1].trim().split("\\|");
						ArrayList<WordIdf> wi = new ArrayList<WordIdf>();
						for(String word_idf:words_idfs){
							String[] temp = word_idf.trim().split("\\s");
							if(temp[0].equalsIgnoreCase("")){
								System.out.print("fdafa");
							}
							WordIdf woid = new WordIdf(Integer.valueOf(temp[0]),Double.valueOf(temp[1]));
							wi.add(woid);
						}
						entity_description.put(entity_id, wi);
					}
					out_entity_size++;
			}
			out_entity_embedding = new double[out_entity_size][dim_num];
			for(int i = 0;i<out_entity_size;i++){
				out_entity_embedding[i] = cal_ent_sem(i); 
			}
			
			
		}catch(IOException e){
			e.printStackTrace();
		}
	}
	public static void main(String[] args){
		String file2 = "../WN35K/out_entity-definitions_tfidf.txt";
		String word_embedding="../WN35K/word_embedding(lr0.01_rlr0.01_wlr0.01_dim50_gamma2.0_wbow).txt";
		String model_file_A="../WN35K/entity_embedding(lr0.01_rlr0.01_wlr0.01_dim50_gamma2.0_wbow)_A.txt";
		String model_file_B="../WN35K/entity_embedding(lr0.01_rlr0.01_wlr0.01_dim50_gamma2.0_wbow)_B.txt";
		String fb20k_test_file1="../WN35K/de_triple.txt";
		String fb20k_test_file2="../WN35K/ed_triple.txt";
		String fb20k_test_file3="../WN35K/dd_triple.txt";
		
		int topn=10;
//		String tag = "cbow";
		String tag = "wbow";
		
		JointE_Test evaluation=new JointE_Test(topn,tag);
		evaluation.load_model_A(model_file_A);
		evaluation.load_model_B(model_file_B);
		evaluation.load_model_word_embedding(word_embedding);
		evaluation.load_description(file2);

		//EKB in WN35K Zero-shot Scenorio
		evaluation.load_testdata(fb20k_test_file1,"de");
		evaluation.zs_evaluation("de");
		
		evaluation.load_testdata(fb20k_test_file2,"ed");
		evaluation.zs_evaluation("ed");
		
		evaluation.load_testdata(fb20k_test_file3, "dd");
		evaluation.zs_evaluation("dd");
		
		evaluation.zs_evaluation_all();
		
	}

}
